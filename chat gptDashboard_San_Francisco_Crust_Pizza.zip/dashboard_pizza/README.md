# Cuadro de mando comercial — San Francisco Crust Pizza

Aplicación web interactiva desarrollada con Streamlit y Plotly. Incluye las tres bases originales en `data/` para comenzar inmediatamente.

## Instalación

1. Instalar Python 3.10 o superior.
2. En una terminal, abrir esta carpeta y ejecutar:
   ```bash
   pip install -r requirements.txt
   streamlit run app.py
   ```
3. Abrir la dirección local que muestra Streamlit (normalmente `http://localhost:8501`).

## Actualización sin tocar código

En el panel lateral, cargar un nuevo archivo Excel de **Ventas**. El archivo debe mantener los nombres de las columnas requeridas, especialmente `VentaID`, `Fecha`, `Ciudad`, `Sucursal`, `ClienteID`, `ProductoID`, `Cantidad`, `VentaNeta` y `CostoTotal`. Todos los gráficos, filtros e indicadores se recalculan automáticamente. También se pueden actualizar los maestros de clientes y productos desde el panel. Si no se cargan archivos, se usan los Excel de `data/`.

Para cambiar los archivos de inicio permanentemente, sustituir los archivos correspondientes dentro de `data/` manteniendo el patrón de nombre `*_Ventas.xlsx`, `*_Clientes.xlsx`, `*_Productos.xlsx`; evitar mantener dos archivos del mismo tipo.

## Relaciones

Ventas.ClienteID → Clientes.ClienteID; Ventas.ProductoID → Productos.ProductoID. Se utilizan relaciones muchos-a-uno y se advierte sobre claves maestras duplicadas. La ciudad y sucursal se toman de ventas, no del domicilio del cliente.

## Definición de indicadores

- Ventas totales = suma de `VentaNeta`.
- Utilidad bruta = suma de `VentaNeta - CostoTotal` (recalculada para consistencia).
- Margen bruto (%) = utilidad bruta / ventas totales × 100.
- Ticket promedio = ventas totales / número de `VentaID` distintos.
- Clientes = número de `ClienteID` distintos con ventas dentro de los filtros.
- Transacciones = número de `VentaID` distintos.
- Productos más vendidos = ranking por suma de `Cantidad` (se distingue el tamaño).

## Asistente inteligente

El botón **Generar diagnóstico y recomendaciones** produce recomendaciones explicables basadas en reglas sin coste ni API. La opción **Consultar IA** utiliza un modelo externo mediante una clave API de OpenAI que introduce el usuario o variable de entorno `OPENAI_API_KEY`; esta función requiere conexión a Internet y puede generar cargos según el proveedor. Solo se envían **datos agregados** del filtro, no los registros individuales ni datos personales de clientes. El equipo debe revisar críticamente cualquier recomendación antes de incorporarla a sus conclusiones.

## Alcance y precauciones

- Se presupone que `VentaID` identifica una transacción; validar este criterio con la empresa.
- El precio y costo de productos pueden variar históricamente: los importes monetarios se toman de cada venta y no del catálogo actual.
- Si los meses son incompletos, la comparación mensual puede inducir a error.
- El sistema es de apoyo a decisiones; no ejecuta cambios de precios ni acciones comerciales automáticamente.
